<!-- Small boxes (Stat box) -->
<div class="row">
    <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-success">
            <div class="inner">
                <small><i class="ion-ios-calendar-outline"></i>
                    <?= (empty($otg)) ? 'Belum ada data' : $otg[0]->updated_at  ?></small>
                <h3><?= (empty($otg)) ? 0 : $otg[0]->dalam_pemantauan + $otg[0]->selesai_pemantauan  ?></h3>

                <p>Orang Tanpa Gejalah (OTG)</p>
            </div>
            <div class="icon">
                <i class="fa fa-head-side-mask"></i>
            </div>
            <a href="<?= base_url('/admin/covid19/orang-tanpa-gejalah') ?>" class="small-box-footer">More info <i
                    class="fas fa-arrow-circle-right"></i></a>
        </div>
    </div>
    <!-- ./col -->
    <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-info">
            <div class="inner">
                <small><i class="ion-ios-calendar-outline"></i> <?= (empty($odp)) ? 'Belum ada data' : 1  ?></small>

                <h3><?= (empty($odp)) ? 0 : 1  ?></h3>

                <p>Orang Dalam Pemantauan (ODP)</p>
            </div>
            <div class="icon">
                <i class="fa fa-head-side-cough"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
    </div>
    <!-- ./col -->
    <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-warning">
            <div class="inner">
                <small><i class="ion-ios-calendar-outline"></i> <?= (empty($pdp)) ? 'Belum ada data' : 1  ?></small>

                <h3><?= (empty($pdp)) ? 0 : 1  ?></h3>

                <p>Pasien Dalam Pengawasan (PDP)</p>
            </div>
            <div class="icon">
                <i class="fa fa-hospital-user"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
    </div>
    <!-- ./col -->
    <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-danger">
            <div class="inner">
                <small><i class="ion-ios-calendar-outline"></i> <?= (empty($positif)) ? 'Belum ada data' : 1  ?></small>

                <h3><?= (empty($positif)) ? 0 : 1  ?></h3>

                <p>Positif Covid-19</p>
            </div>
            <div class="icon">
                <i class="fa fa-procedures"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
    </div>
    <!-- ./col -->
</div>
<!-- /.row -->