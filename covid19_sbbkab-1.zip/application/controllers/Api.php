<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Api extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        // if (!isset($this->session->logged_in) || $this->session->logged_in != TRUE) {
        //     $response = [
        //         'status' => 'error',
        //         'message' => 'tidak terautentikasi'
        //     ];

        //     echo json_encode($response);
        //     die;
        //     // redirect('', 'location');
        // }

        $this->load->model('covid_model');
    }

    public function getOTG()
    {
        $data_otg = $this->covid_model->get_covid('otg');
        echo json_encode($data_otg);
    }

    public function postOTG()
    {
        if ($this->input->post()) {
            $POST = $this->input->post();
            // var_dump($POST);
            // die;
            date_default_timezone_set("Asia/Jayapura");
            // $time = Time::now('Asia/Jayapura', 'en_US');

            $user = $this->session->user;
            // $user = $auth['user'];
            $data = [
                'dalam_pemantauan' => $POST['dalam_pemantauan'],
                'selesai_pemantauan' => $POST['selesai_pemantauan'],
                'updated_by' => $user->id,
                'updated_at' => date("Y-m-d H:i:s")
            ];
            $response = $this->covid_model->save_covid('otg', $data);

            echo json_encode($response);
        }
    }

    public function removeCovid()
    {
        if ($this->input->post()) {
            $POST = $this->input->post();
            $table = $POST['table'];
            $id = $POST['id'];
            $response = $this->covid_model->remove_covid($table, $id);

            echo json_encode($response);
        }
    }
}