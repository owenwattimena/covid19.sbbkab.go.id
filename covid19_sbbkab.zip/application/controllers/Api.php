<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Api extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        if (!isset($this->session->logged_in) || $this->session->logged_in != TRUE) {
            $response = [
                'status' => 'error',
                'message' => 'tidak terautentikasi'
            ];

            echo json_encode($response);
            die;
        }

        $this->load->model('covid_model');
    }


    public function getCovid($table)
    {
        $data_otg = $this->covid_model->get_covid($table);
        echo json_encode($data_otg);
    }

    public function getOTG()
    {
        $this->getCovid('otg');
    }

    public function getODP()
    {
        $this->getCovid('odp');
    }

    public function getPDP()
    {
        $this->getCovid('pdp');
    }

    public function getPositif()
    {
        $this->getCovid('positif_covid');
    }

    private function postCovid($table, $post)
    {
        if ($post) {
            date_default_timezone_set("Asia/Jayapura");
            $user = $this->session->user;

            $POST = $post;
            $POST['updated_by'] = $user->id;
            $POST['updated_at'] = date("Y-m-d H:i:s");

            $response = $this->covid_model->save_covid($table, $POST);
            echo json_encode($response);
        }
    }

    public function postOTG()
    {
        $this->postCovid('otg', $this->input->post());
    }

    public function postODP()
    {
        $this->postCovid('odp', $this->input->post());
    }

    public function postPDP()
    {
        $this->postCovid('pdp', $this->input->post());
    }

    public function postPositif()
    {
        $this->postCovid('positif_covid', $this->input->post());
    }

    public function removeCovid()
    {
        if ($this->input->post()) {
            $POST = $this->input->post();
            $table = $POST['table'];
            $id = $POST['id'];
            $response = $this->covid_model->remove_covid($table, $id);

            echo json_encode($response);
        }
    }
}