<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Covid
{

    public function genereteDateTime($timestamp)
    {

        $hari = [
            'Sunday' => 'Minggu',
            'Monday' => 'Senin',
            'Tuesday' => 'Selasa',
            'Wednesday' => 'Rabu',
            'Thursday' => 'Kamis',
            'Friday' => 'Jum\'at',
            'Saturday' => 'Sabtu',
        ];


        $datetime = DateTime::createFromFormat('Y-m-d H:i:s', $timestamp);
        $Day = $datetime->format('l');
        $date = date('d-m-Y', strtotime($timestamp));
        $time = date('H:i-s', strtotime($timestamp));

        $format = $hari[$Day] . ', ' . $date . ' - ' . $time;

        return $format;
    }
}