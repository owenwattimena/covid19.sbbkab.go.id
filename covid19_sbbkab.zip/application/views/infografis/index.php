<section class="hero-wrap" style="height: 250px;background-image: url('<?= base_url() ?>/assets/site/images/bg_1.jpg');"
    data-stellar-background-ratio="0.5">
    <div class="overlay"></div>
    <div class="container">

    </div>
</section>


<!-- - - - - -end- - - - -  -->

<section class="ftco-section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-9 text-center">
                <h2 class="heading-section mb-4 pb-md-3">
                    Infografis
                </h2>

                <section class="ftco-section ftco-no-pt ftco-no-pb" id="carousel">
                    <div class="px-0">
                        <div class="row no-gutters justify-content-center">
                            <div class="col-md-12">
                                <div id="demo" class="carousel slide" data-ride="carousel">

                                    <!-- Indicators -->
                                    <ul class="carousel-indicators">
                                        <li data-target="#demo" data-slide-to="0" class="active"></li>
                                        <li data-target="#demo" data-slide-to="1"></li>
                                        <!-- <li data-target="#demo" data-slide-to="2"></li> -->
                                    </ul>

                                    <!-- The slideshow -->
                                    <div class="carousel-inner">
                                        <div class="carousel-item active bg-primary" style="height: 750px;">
                                            <!-- <div class="overlay"></div> -->
                                            <div class="container">
                                                <div class="row ">
                                                    <div class="col-md-12 text-center">
                                                        <img src="https://m.ayobandung.com/images-bandung/post/articles/2020/05/28/90881/corona_cirus.jpg"
                                                            alt="" class="img-fluid " style="height: 750px;">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="carousel-item  bg-danger" style="height: 750px;">
                                            <!-- <div class="overlay"></div> -->
                                            <div class="container">
                                                <div class="row ">
                                                    <div class="col-md-12 text-center">
                                                        <img src="https://m.ayobandung.com/images-bandung/post/articles/2020/05/28/90881/corona_cirus.jpg"
                                                            alt="" class="img-fluid " style="height: 750px;">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- <div class="carousel-item bg-warning" style="height: 750px">
									<div class="container">
										<div
											class="row slider-text px-4 d-flex align-items-center justify-content-center">
											<div class="col-md-8 text w-100 text-center">
												<h2 class="mb-4">Get Smash Free UI Kit</h2>
												<p><a href="#" class="btn btn-outline-white btn-round">See all
														components</a></p>
											</div>
										</div>
									</div>
								</div> -->
                                    </div>

                                    <!-- Left and right controls -->
                                    <a class="carousel-control-prev" href="#demo" data-slide="prev">
                                        <span class="ion-ios-arrow-round-back"></span>
                                    </a>
                                    <a class="carousel-control-next" href="#demo" data-slide="next">
                                        <span class="ion-ios-arrow-round-forward"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

            </div>
        </div>
    </div>
</section>
<!-- - - - - -end- - - - -  -->